<?php
// menampilkan daftar produk
require '../koneksi_db.php'; // include the database connection file

// Ambil semua produk untuk ditampilkan pada tabel.
$sql = "SELECT * FROM products";
$stmt = $pdo->query($sql);
$products = $stmt->fetchAll();

?>

<!DOCTYPE html>
<html>
<head>
    <title>Daftar Produk</title>
</head>
<body>
    <h1>Daftar Produk</h1>
    <a href="form/create_form.php">Tambah Produk Baru</a>
    <table border="1">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nama</th>
                <th>Harga</th>
                <th>Deskripsi</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($products): ?>
                <?php foreach ($products as $product): ?>
                    <tr>
                        <!-- Amankan output agar data produk tidak diproses sebagai HTML. -->
                        <td><?php echo htmlspecialchars($product['id']); ?></td>
                        <td><?php echo htmlspecialchars($product['name']); ?></td>
                        <td><?php echo htmlspecialchars($product['price']); ?></td>
                        <td><?php echo htmlspecialchars($product['description']); ?></td>
                        <td>
                            <a href="form/edit_form.php?id=<?php echo $product['id']; ?>">Edit</a>
                            <form action="crud_process/delete.php" method="POST" style="display:inline;">
                                <input type="hidden" name="id" value="<?php echo $product['id']; ?>">
                                <input type="submit" value="Hapus" onclick="return confirm('Apakah Anda yakin ingin menghapus produk ini?')">
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="5">Belum ada produk.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</body>
</html>