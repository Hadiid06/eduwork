NUSAMART - DASHBOARD E-COMMERCE (HALAMAN PENGGUNA)

ISI
- Dashboard pengguna dengan kategori, produk pilihan, pencarian, dan filter kategori.
- database.sql berisi skema database serta data contoh kategori dan produk.
- Halaman hanya membaca data untuk ditampilkan. Tidak ada fitur CRUD, login,
  keranjang yang berfungsi, atau proses transaksi.

CARA MENJALANKAN
1. Jalankan Apache dan MySQL melalui XAMPP.
2. Buka http://localhost/phpmyadmin dan impor file database.sql.
3. Buka http://localhost/eduwork/sesi-9/
4. Jika kredensial MySQL berbeda dari konfigurasi XAMPP default, sesuaikan
   koneksi di koneksi_db.php.
